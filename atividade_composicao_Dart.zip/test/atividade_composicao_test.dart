import 'package:atividade_composicao/cliente.dart';
import 'package:atividade_composicao/produto.dart';
import 'package:atividade_composicao/venda_item.dart';
import 'package:atividade_composicao/venda.dart';

void main() {
  Cliente cliente = Cliente(
    nome: 'João',
    cpf: 123456789,
  );

  Produto produto = Produto(
    codigo: 1,
    nome: 'Celular',
    preco: 1000,
    desconto: 10,
  );

  VendaItem item = VendaItem(
    produto: produto,
    quantidade: 2,
  );

  Venda venda = Venda(
    cliente: cliente,
    itens: [item],
  );

  assert(produto.precoComDesconto == 900);
  assert(item.preco == 900);
  assert(venda.valorTotal == 1800);
}
